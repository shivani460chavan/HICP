from django.apps import AppConfig


class TheAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "the_app"
